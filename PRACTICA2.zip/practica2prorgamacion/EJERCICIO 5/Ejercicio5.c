#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

    float num_1, num_2; 
    int operador;
    float total;
    
    printf("Introduzca el primer numero:\n");
    scanf("%f",&num_1);
    
    printf("Introduzca el segundo numero:\n");
    scanf("%f",&num_2);
    
    printf("1.Suma\n 2.Resta\n 3.Multiplicacion\n 4.Division\n 5.Salir\n");
    
    

while(operador!=5){
    
	printf("\n\nSelecciona una opcion\n");
    scanf("%d",&operador);
    
   switch(operador){
       case 1:
       total=num_1+num_2;
       break;
       case 2:
       total=num_1-num_2;
       break;
       case 3:
       total=num_1*num_2;
       break;
       case 4:
       total=num_1/num_2;
       break;
   }
    printf("Resultado:%.2f",total);
}
	
    getch();
}

