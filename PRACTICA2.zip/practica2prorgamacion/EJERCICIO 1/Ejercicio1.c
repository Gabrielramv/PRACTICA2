#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float x, fx;
  
  printf("Ingrese el valor de x:\n");
  scanf("%f",&x);
  
  if(x<=0){     
           fx=(x*x)-x;
           }
           
           else{
                fx=-(x*x)+(3*x);
                }                 
   printf("fx=\n%.2f\n",fx);                                        
  
  
  
  system("PAUSE");	
  return 0;
}
