#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int np, seleccion;
	int total=0;
	

        printf( "\n 1. Hamburguesa chica con papas:\t$20");
        printf( "\n 2. Hotdog y refresco:\t\t$18");
        printf( "\n 3. Ensalada rusa:\t\t$15");
        
        printf( "\n Introduzca el numero de productos:\n");
		scanf( "%d", &np);

		for(np=np;np!=0;np--){
			
		printf("Introduzca el producto que desea:\n");
		scanf("%d", &seleccion);
        
		switch (seleccion)
        {
            case 1: total=total+20;
                    break;

            case 2: total=total+18;
                    break;

            case 3: total=total+15;
            		break;
         }
	   }
	
	printf("Total:%d", total);
	
	
	
 getch();
}
