#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int kwh;
	float costo=0;
	
	printf("Este es un programa que calcula el costo de los kwh\n");
    printf("Ingresar el valor de los kwh consumidos:\n");
	scanf("%d",&kwh);
	
	if(kwh<=50){
		costo=(kwh*2.288)+52.84;
	}
	else{
		if(kwh<=100){
			costo=(50*2.288)+52.84+((kwh-50)*2.762);
		}
		else{
			costo=(50*2.762)+52.84+(50*2.288)+((kwh-100)*3.042);
		}
	}
	printf("Costo total:%f \n",costo);
	
	getch();

}
