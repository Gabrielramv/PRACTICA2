#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int main(int argc, char *argv[]){
  int HR,tomate,melon,pepino,calabacita,A,B,cosecha,CC;
  int i=0;
  
  		printf("Cultivos invernadero:\n");
  		
		printf("1) Tomate         50 a 60\n");
 		printf("2) Melon          60 a 70\n");
  		printf("3) Pepino         70 a 90\n");
  			
  		printf("Indique lo que desea cosechar:\n");
  		scanf("%d",&cosecha);
  		
  		printf("Tambien puede cosechar Calabacita al mismo tiempo\n Desea hacerlo?\n");
  	
  		printf("1) Si\n");
  		printf("2) No\n");
  			
		scanf("%d",&CC);
		
  		printf("Indique la humedad relativa:\n");
  		scanf("%d",&HR);
  
   for(i=0;i<=6;i++){
   	
    switch(CC){
    case 1:
     printf("Calabacita:\n");
     if (HR<55){
        printf("Se hace un riego por 3 segundos\n");
        }
		else{ 
			if (HR>80){
          		printf("Se abren las ventilas por 5 segundos\n");
         		}
         	else{
         	printf("La humedad es la optima\n");
         		}
         	}
    break;
    
    case 2:
         printf("");    
    break;
    
    default:
     printf ("Opcion erronea");
    break;
    
   }
   
    switch(cosecha){
     case 1:
      printf("Tomate:\n");
         
		 if (HR<50){
         printf("Se hace un riego por 3 segundos\n");
         HR+=(HR*0.04);
         }
		 else{ 
		 	if (HR>60){
          	printf("Se abren las ventilas por 5 segundos\n");
          	HR-=(HR*0.03);
        	}
         	else{
         	printf("La humedad es la optima\n");
         	}
         	}	
     break;
     
	 case 2:
      printf("Melon\n");
      
      if (HR<60){
         printf("Se hace un riego por 3 segundos\n");
         HR+=(HR*0.04);
         }
		 else{
		 if (HR>70){
          printf("Se abren las ventilas por 5 segundos\n");
          HR-=(HR*0.03);
         }
         else{
         printf("La humedad es la optima\n");
         }
         }
     break;
     case 3:
      printf("Pepino:");
      
       if (HR<70){
         printf("Se hace un riego por 3 segundos\n");
         HR+=(HR*0.04);
         }else{ 
		 if (HR>90){
          printf("Se abren las ventilas por 5 segundos\n");
          HR-=(HR*0.03);
         }
         else{
         printf("La humedad es la optima\n");
         }
         }
     break;
     
     default:
     printf ("Opcion erronea\n");
     break;
     
     }
   printf("\n");
  Sleep(1000); 
  }
  system("PAUSE");	
  return 0;
}
