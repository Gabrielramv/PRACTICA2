#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float x;
	float fx;
	
	printf("Este programa va a mostrar los valores de sin(2x)-x de 0 hasta 9.5\n");
    for(x=0;x<=10;x+=0.5){
		
	fx=sin(2*x)-(x);
		
	printf("%.2f\n",fx);		
	}
	
	getch();
}
