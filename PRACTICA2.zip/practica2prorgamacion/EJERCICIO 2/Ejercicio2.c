#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float sum=0;
  float cant=0;
  float calif,prom;
  
  for(cant=0;cant<5;cant++){
  
  printf("Ingrese la calificacion:\n");
  scanf("%f",&calif);
  
  sum+=calif;
  }
  
  prom=sum/5;
   
  printf("Su promedio es:\n%.2f\n", prom);  
  
  if(prom<6){
             printf("REPROBADO\n");
             }
             else{
                  printf("APROBADO\n");
                  }
                          
  system("PAUSE");	
  return 0;
}
